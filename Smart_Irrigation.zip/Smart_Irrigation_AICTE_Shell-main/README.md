# Smart_Irrigation_AICTE_Shell
This is an AICTE Internship Cycle 2
